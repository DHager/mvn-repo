This zip file contains DLLs for use with the jhllib java library, provided for convenience. To use these DLLs with jhllib, they must be inside the working directory for your application, or before calling the library your code must set the relevant system property:

    System.setProperty("jna.library.path",path_where_dlls_exist);

They are provided under the LGPL 2.1, and are copyright (c) Nem 2010. (http://nemesis.thewavelength.net/index.php?p=35)